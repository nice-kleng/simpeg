<?php

namespace App\Exports;

use App\Models\Marketing;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class TurlapExport implements FromArray, WithHeadings
{
    // protected $startDate;
    // protected $endDate;

    // public function __construct($startDate, $endDate)
    // {
    //     $this->startDate = $startDate;
    //     $this->endDate = $endDate;
    // }

    public function headings(): array
    {
        $headers = ['No', 'Nama', 'Maps', 'Rating', 'Alamat', 'No. Telp', 'Tanggal', 'Status Prospek', 'PIC'];

        $marketing = Marketing::with('followUp')->get();

        $maxFollowUps = $marketing->map(function ($item) {
            return $item->followUp->count();
        });

        for ($i = 0; $i < $maxFollowUps->max(); $i++) {
            $headers[] = "Follow FU $i Tanggal FU";
            $headers[] = "Keterangan";
        }

        return $headers;
    }

    public function array(): array
    {
        $marketings = Marketing::with('followUp')->get();

        $data = [];

        foreach ($marketings as $key => $marketing) {
            $row = [
                $key + 1,
                $marketing->nama,
                $marketing->maps,
                $marketing->rating,
                $marketing->alamat,
                $marketing->no_telp,
                $marketing->tanggal,
                $marketing->status_prospek,
                $marketing->pics->pluck('name')->implode(', '),
            ];

            foreach ($marketing->followUp as $key => $followUp) {
                $row[] = $followUp->tanggal;
                $row[] = $followUp->keterangan;
            }
            $data[] = $row;
        }

        return $data;
    }
}
