<?php $__env->startPush('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('button-action'); ?>
    <a href="<?php echo e(route('brand.index')); ?>" class="btn btn-secondary btn-sm pull-right ml-2">Kembali</a>
    <a href="javascript:void(0)" data-toggle="modal" data-target="#brandModal" class="btn btn-primary btn-sm pull-right">Input
        Brand</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x_title">
                    <a href="<?php echo e(route('brand.unduhTemplateImport', $sumberMarketing->id)); ?>"
                        class="btn btn-success btn-sm"><i class="fa fa-download"></i> Template Import</a>
                    <a href="javascript:void(0)" data-toggle="modal" data-target="#importModal"
                        class="btn btn-danger btn-sm"><i class="fa fa-upload"></i> Import Brand</a>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover text-nowrap" id="brand-table" width="100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Rating</th>
                                    <th>Alamat</th>
                                    <th>No HP</th>
                                    <th>Brand</th>
                                    <th>Pic</th>
                                    <th>Pic Sign</th>
                                    <th>Maps</th>
                                    <th>Tanggal</th>
                                    <th>Status Follow Up</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sumberMarketing->marketings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($marketing->nama); ?></td>
                                        <td><?php echo e($marketing->rating); ?></td>
                                        <td><?php echo e($marketing->alamat); ?></td>
                                        <td><?php echo e($marketing->no_hp); ?></td>
                                        <td><?php echo e($marketing->brand); ?></td>
                                        <td><?php echo e($marketing->pics->pluck('name')->implode(', ')); ?></td>
                                        <td><?php echo e($marketing->picSign->pluck('name')->implode(', ')); ?></td>
                                        <td><?php echo e($marketing->maps); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($marketing->tanggal)->locale('id')->isoFormat('D MMMM YYYY')); ?>

                                        </td>
                                        <td>
                                            <?php
                                                $lastFollowUp = $marketing->followUp->last();
                                                $status = $lastFollowUp
                                                    ? $lastFollowUp->getRawOriginal('status')
                                                    : null;
                                                $badgeColor = '';
                                                $badgeText = 'Not Started';

                                                if ($status === '1') {
                                                    $badgeColor = 'primary';
                                                    $badgeText = 'Follow Up';
                                                } elseif ($status === '2') {
                                                    $badgeColor = 'danger';
                                                    $badgeText = 'Ditolak';
                                                } elseif ($status === '3') {
                                                    $badgeColor = 'success';
                                                    $badgeText = 'Join';
                                                } else {
                                                    $badgeColor = 'secondary';
                                                }
                                            ?>
                                            <span class="badge badge-<?php echo e($badgeColor); ?>">
                                                <?php echo e($badgeText); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <a href="javascript:void(0)" data-id="<?php echo e($marketing->id); ?>"
                                                class="btn btn-primary btn-sm btn-edit">Edit</a>
                                            <a href="javascript:void(0)"
                                                data-url="<?php echo e(route('brand.destroy', $marketing->id)); ?>"
                                                onclick="deleteData(this)"
                                                class="btn btn-danger btn-sm btn-delete">Hapus</a>
                                            <a href="<?php echo e(route('brand.followUp', $marketing->id)); ?>"
                                                class="btn btn-info btn-sm btn-followup">Follow Up</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- modal tambah turlap -->
    <div class="modal fade" id="brandModal">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="brandModalLabel">Tambah Brand</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('brand.store')); ?>" method="POST" id="brandForm">
                        <div id="mtd"></div>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <input type="text" name="nama" id="nama" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="maps">Maps</label>
                                    <input type="text" name="maps" id="maps" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="alamat">Alamat</label>
                                    <input type="text" name="alamat" id="alamat" class="form-control">
                                    <input type="hidden" name="sumber_marketing_id" value="<?php echo e($sumberMarketing->id); ?>">
                                    <input type="hidden" name="label" value="Brand">
                                </div>
                                <div class="form-group">
                                    <label for="no_hp">No HP</label>
                                    <input type="text" name="no_hp" id="no_hp" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="brand">Brand</label>
                                    <input type="text" name="brand" id="brand" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="rating">Rating</label>
                                    <select name="rating" id="rating" class="form-control">
                                        <option value="0">Not Rated</option>
                                        <option value="1">Minat & Mampu</option>
                                        <option value="2">Minat Tidak Mampu</option>
                                        <option value="3">Tidak Minat Mampu</option>
                                        <option value="4">Tidak Minat Tidak Mampu</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="tanggal">Tanggal</label>
                                    <input type="date" name="tanggal" id="tanggal" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="status_prospek">Status Prospek</label>
                                    <select name="status_prospek" id="status_prospek" class="form-control">
                                        <option value="Not Status">Not Status</option>
                                        <option value="Prospek">Prospek</option>
                                        <option value="Non Prospek">Non Prospek</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="pics">PIC</label>
                                    <select name="pics[]" id="pics" class="form-control select2"
                                        style="width: 100%" multiple>
                                        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="picSign">PIC Sign</label>
                                    <select name="picSign[]" id="picSign" class="form-control select2"
                                        style="width: 100%" multiple>
                                        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- modal import turlap -->
    <div class="modal fade" id="importModal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title">Import Data Turlap
                        <?php echo e(Str::ucfirst($sumberMarketing->nama_sumber_marketing)); ?></div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('brand.import')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="file" name="file" id="file" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-sm">Import</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#brand-table').DataTable();

            $('.select2').select2({
                allowClear: true,
            });

            // $('#turlapModal').on('show.bs.modal', function(event) {
            //     var button = $(event.relatedTarget);
            //     var id = button.data('id');

            //     if (id) {
            //         $('#turlapModalLabel').text('Edit Turlap');
            //     } else {
            //         $('#turlapModalLabel').text('Tambah Turlap');
            //     }

            //     $.ajax({
            //         url: "<?php echo e(route('turlap.edit', ':id')); ?>".replace(':id', id),
            //         type: 'GET',
            //         success: function(response) {
            //             console.log(response);
            //         }
            //     });
            // });

            $('#brand-table').on('click', '.btn-edit', function() {
                var id = $(this).data('id');

                $.ajax({
                    url: "<?php echo e(route('brand.edit', ':id')); ?>".replace(':id', id),
                    type: 'GET',
                    success: function(response) {
                        console.log(response);

                        $('#brandModalLabel').text('Edit Brand');
                        $('#nama').val(response.nama);
                        $('#maps').val(response.maps);
                        $('#alamat').val(response.alamat);
                        $('#no_hp').val(response.no_hp);
                        $('#brand').val(response.brand);
                        $('#rating').val(response.rating_raw);
                        $('#tanggal').val(response.tanggal);
                        $('#status_prospek').val(response.status_prospek);
                        $('#pics').val(response.pics).trigger('change');
                        $('#picSign').val(response.picSign).trigger('change');
                        $('#brandModal').modal('show');

                        $('#mtd').html('<input type="hidden" name="_method" value="PUT">');
                        $('#brandForm').attr('action', "<?php echo e(route('brand.update', ':id')); ?>"
                            .replace(':id', id));
                    }
                });
            });

            $('#turlapModal').on('hidden.bs.modal', function() {
                $('#brandForm')[0].reset();
                $('#brandForm').attr('action', "<?php echo e(route('brand.store')); ?>");
                $('#mtd').html('');
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageTitle' => 'Data Brand ' . $sumberMarketing->nama_sumber_marketing], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\simpeg\resources\views/marketing/brand/detailBrand.blade.php ENDPATH**/ ?>