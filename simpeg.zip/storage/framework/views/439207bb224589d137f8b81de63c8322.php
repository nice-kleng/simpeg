<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
            

            

            <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Home </a></li>
            <li><a><i class="fa fa-table"></i> Data Master <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('jabatan.index')); ?>">Jabatan</a></li>
                    <li><a href="<?php echo e(route('pegawai.index')); ?>">Pegawai</a></li>
                    <li><a href="<?php echo e(route('product.index')); ?>">Product</a></li>
                    <li><a href="<?php echo e(route('mitra.index')); ?>">Mitra</a></li>
                </ul>
            </li>

            <li><a><i class="fa fa-share-alt"></i> Sosmed <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('timelineInstagram.index')); ?>">Timeline Instagram</a></li>
                    <li><a href="<?php echo e(route('timelineTikTok.index')); ?>">Timeline TikTok</a></li>
                    
                    <li><a href="<?php echo e(route('reportTikTokLive.index')); ?>">Report TikTok Live</a></li>
                </ul>
            </li>

            <li><a><i class="fa fa-bullseye"></i> Marketing <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a>Turlap<span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo e(route('turlap.index')); ?>">Input Turlap</a>
                            </li>
                            <li class="sub_menu"><a href="<?php echo e(route('turlap.tampilTurlap')); ?>">View</a>
                            </li>
                            <li><a href="<?php echo e(route('turlap.preview')); ?>">Report</a>
                            </li>
                        </ul>
                    </li>
                    <li><a>Leads<span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo e(route('leads.index')); ?>">Input Leads</a>
                            </li>
                            <li class="sub_menu"><a href="<?php echo e(route('leads.tampilLeads')); ?>">View</a>
                            </li>
                            <li><a href="<?php echo e(route('leads.preview')); ?>">Report</a>
                            </li>
                        </ul>
                    </li>
                    <li><a>Brand<span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li class="sub_menu"><a href="<?php echo e(route('brand.index')); ?>">Input Brand</a>
                            </li>
                            <li class="sub_menu"><a href="<?php echo e(route('brand.tampilBrand')); ?>">View</a>
                            </li>
                            <li><a href="<?php echo e(route('brand.preview')); ?>">Report</a>
                            </li>
                        </ul>
                    </li>

                    
                    
                </ul>
            </li>

            <li><a><i class="fa fa-users"></i> CRM <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('crm.pertanyaan.index')); ?>">Pertanyaan</a></li>
                    <li><a href="<?php echo e(route('crm.jadwalKunjungan.index')); ?>">Jadwal Kunjungan</a></li>
                </ul>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH D:\Web Development\simpeg\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>