

<?php $__env->startSection('content'); ?>

<?php

    $dashboards = [
        'sosmed_kadiv' => [
            'permission' => 'View Sosmed Kadiv Dashboard',
            'view' => 'dashboards.kadiv_sosmed',
        ],
        'sosmed_staff' => [
            'permission' => 'View Sosmed Pegawai Dashboard',
            'view' => 'dashboards.staff_sosmed',
        ],
        'marketing_kadiv' => [
            'permission' => 'View Marketing Kadiv Dashboard',
            'view' => 'dashboards.kadiv_marketing',
        ],
        'marketing_staff' => [
            'permission' => 'View Marketing Pegawai Dashboard',
            'view' => 'dashboards.staff_marketing',
        ]
    ];

    $userDashboards = collect($dashboards)->filter(function ($dashboard) {
        return auth()->user()->can($dashboard['permission']);
    });

    // batasi hanya pada dashboard kadiv
    // if (auth()->user()->hasRole('Super Admin')) {
    //     $userDashboards = $userDashboards->filter(function ($dashboard, $key) {
    //         return str_contains($key, 'kadiv');
    //     });
    // }

?>

<?php $__currentLoopData = $userDashboards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dashboard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make($dashboard['view'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['pageTitle' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\simpeg\resources\views/dashboards/dashboard.blade.php ENDPATH**/ ?>