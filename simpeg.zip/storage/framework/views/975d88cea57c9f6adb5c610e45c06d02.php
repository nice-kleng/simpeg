

<?php $__env->startSection('button-action'); ?>
<a href="<?php echo e(route('turlap.detailTurlapByArea', $turlap->sumber_marketing_id)); ?>" class="btn btn-secondary btn-sm pull-right ml-2">Kembali</a>
<a href="javascript:void(0)" data-toggle="modal" data-target="#followUpModal"
    class="btn btn-primary btn-sm pull-right">Input Follow Up</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Follow Up Turlap</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-nowrap" width="100%">
                        <tr>
                            <th>Nama : </th>
                            <td><?php echo e($turlap->nama); ?></td>
                        </tr>
                        <tr>
                            <th>Alamat : </th>
                            <td><?php echo e($turlap->alamat); ?></td>
                        </tr>
                        <tr>
                            <th>Maps : </th>
                            <td><?php echo e($turlap->maps); ?></td>
                        </tr>
                        <tr>
                            <th>Rating : </th>
                            <td><?php echo e($turlap->rating); ?></td>
                        </tr>
                        <tr>
                            <th>Status Prospek : </th>
                            <td><?php echo e($turlap->status_prospek); ?></td>
                        </tr>
                        <tr>
                            <th>Tanggal : </th>
                            <td><?php echo e(\Carbon\Carbon::parse($turlap->tanggal)->locale('id')->isoFormat('D MMMM YYYY')); ?></td>
                        </tr>
                        <tr>
                            <th>Status Follow Up : </th>
                            <td><?php echo e($turlap->followUp->last()->status ?? 'Not Started'); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-5">
    <div class="col-md-12 col-sm-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Follow Up Turlap</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-nowrap" id="followUp-table" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Status</th>
                                <th>Keterangan</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $turlap->followUp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($followUp->status); ?></td>
                                <td><?php echo e($followUp->keterangan); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($followUp->tanggal)->locale('id')->isoFormat('D MMMM YYYY')); ?></td>
                                <td>
                                    <a href="javascript:void(0)" data-id="<?php echo e($followUp->id); ?>"
                                        class="btn btn-primary btn-sm btn-edit">Edit</a>
                                    <a href="javascript:void(0)" data-url="<?php echo e(route('turlap.followUpDestroy', $followUp->id)); ?>"
                                        onclick="deleteData(this)" class="btn btn-danger btn-sm btn-delete">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- modal add follow up turlap -->
<div class="modal fade" id="followUpModal" tabindex="-1" role="dialog" aria-labelledby="followUpModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="followUpModalLabel">Input Follow Up</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('turlap.followUpStore', $turlap->id)); ?>" method="POST" id="followUpForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="1">Follow Up</option>
                            <option value="2">Ditolak</option>
                            <option value="3">Join</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="keterangan">Keterangan</label>
                        <input type="text" name="keterangan" id="keterangan" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="tanggal">Tanggal</label>
                        <input type="date" name="tanggal" id="tanggal" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#followUp-table').DataTable();

        $('#followUp-table').on('click', '.btn-edit', function () {
            var id = $(this).data('id');
            
            $.ajax({
                type: "get",
                url: "<?php echo e(route('turlap.followUpEdit', $turlap->id)); ?>",
                data: {
                    id: id
                },
                dataType: "json",
                success: function (response) {                    
                    $('#followUpModalLabel').text('Edit Follow Up');
                    $('#status').val(response.status_raw).trigger('change');
                    $('#keterangan').val(response.keterangan);
                    $('#followup').val(response.followup);
                    $('#tanggal').val(response.tanggal);
                    $('#followUpModal').modal('show');

                    $('#followUpForm').append('<input type="hidden" name="_method" value="PUT">');
                    $('#followUpForm').attr('action', "<?php echo e(route('turlap.followUpUpdate', ':id')); ?>".replace(':id', id));
                }
            });
        });

        $('#followUpModal').on('hidden.bs.modal', function() {
            $('#followUpForm')[0].reset();
            $('#followUpForm').attr('action', "<?php echo e(route('turlap.followUpStore', $turlap->id)); ?>");
            $('#followUpForm').find('input[name="_method"]').remove();
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageTitle' => 'Follow Up Turlap'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\simpeg\resources\views/marketing/turlap/followUp.blade.php ENDPATH**/ ?>