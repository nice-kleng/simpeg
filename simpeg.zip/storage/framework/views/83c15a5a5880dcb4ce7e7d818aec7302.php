

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Edit Data Pegawai</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form action="<?php echo e(route('pegawai.update', $pegawai->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($pegawai->nama); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" class="form-control" id="nik" name="nik" value="<?php echo e($pegawai->nik); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($pegawai->akun->email); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="wa">No. HP</label>
                        <input type="text" class="form-control" id="wa" name="wa" value="<?php echo e($pegawai->wa); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="ttl">Tempat, Tanggal Lahir</label>
                        <input type="text" class="form-control" id="ttl" name="ttl" value="<?php echo e($pegawai->ttl); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <textarea class="form-control" id="alamat" name="alamat" required><?php echo e($pegawai->alamat); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="jenkel">Jenis Kelamin</label>
                        <select class="form-control" id="jenkel" name="jenkel" required>
                            <option value="Laki-laki" <?php echo e($pegawai->jenkel == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                            <option value="Perempuan" <?php echo e($pegawai->jenkel == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="jabatan_id">Jabatan</label>
                        <select class="form-control" id="jabatan_id" name="jabatan_id" required>
                            <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jabatan->id); ?>" <?php echo e($pegawai->jabatan_id == $jabatan->id ? 'selected' : ''); ?>><?php echo e($jabatan->nama_jabatan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="foto">Foto</label>
                        <input type="file" class="form-control" id="foto" name="foto">
                        <?php if($pegawai->foto): ?>
                            <img src="<?php echo e(asset('storage/' . $pegawai->foto)); ?>" width="100">
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageTitle' => 'Edit Data Pegawai'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\simpeg\resources\views/superadmin/pegawai/edit.blade.php ENDPATH**/ ?>