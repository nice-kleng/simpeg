<?php if($row->pertanyaan && $row->pertanyaan()->count() < 1): ?>
    <a href="<?php echo e(route('crm.jadwalKunjungan.jawabanMitra', $row->id)); ?>" class="btn btn-success btn-sm">Isi Jawaban</a>
<?php endif; ?>
<a href="javascript:void(0)" class="btn btn-warning btn-sm edit" data-id="<?php echo e($row->id); ?>">Edit</a>
<a href="javascript:void(0)" class="delete btn btn-danger btn-sm" data-id="<?php echo e($row->id); ?>">Delete</a>
<?php /**PATH D:\Web Development\simpeg\resources\views/crm/jadwal/action-buttons.blade.php ENDPATH**/ ?>