<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View Sosmed Pegawai Dashboard')): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4>Dashboard</h4>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-caret-square-o-right"></i>
                                </div>
                                <div class="count"><?php echo e($tiktok_video); ?></div>

                                <h4>Tiktok Video</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-plus-square"></i>
                                </div>
                                <div class="count"><?php echo e($feed_instagram); ?></div>

                                <h4>Feed Instagram</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-play-circle"></i>
                                </div>
                                <div class="count"><?php echo e($story_instagram); ?></div>

                                <h4>Story Instagram</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-plus-square-o"></i>
                                </div>
                                <div class="count"><?php echo e($total_project_all); ?></div>

                                <h4>Total Project</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-refresh"></i>
                                </div>
                                <div class="count"><?php echo e($project_ongoing); ?></div>

                                <h4>Project Ongoing</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-check-square-o"></i>
                                </div>
                                <div class="count"><?php echo e($project_completed); ?></div>

                                <h4>Project Completed</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-user-plus"></i>
                                </div>
                                <div class="count"><?php echo e($new_tiktok_follower); ?></div>

                                <h4>New Tiktok Follower</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-instagram"></i>
                                </div>
                                <div class="count"><?php echo e($new_ig_follower); ?></div>

                                <h4>New Instagram Follower</h4>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
<?php endif; ?><?php /**PATH D:\Web Development\simpeg\resources\views/dashboards/staff_sosmed.blade.php ENDPATH**/ ?>