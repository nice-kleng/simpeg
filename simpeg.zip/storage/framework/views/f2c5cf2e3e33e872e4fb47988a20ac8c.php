<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View Marketing Pegawai Dashboard')): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4>Dashboard Staff Marketing</h4>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-caret-square-o-right"></i>
                                </div>
                                <div class="count"><?php echo e($turlap); ?></div>

                                <h4>Turlap</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-plus-square"></i>
                                </div>
                                <div class="count"><?php echo e($leads); ?></div>

                                <h4>Leads</h4>
                                
                            </div>
                        </div>
                        <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-3">
                            <div class="tile-stats">
                                <div class="icon"><i class="fa fa-play-circle"></i>
                                </div>
                                <div class="count"><?php echo e($brand); ?></div>

                                <h4>Brand</h4>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
<?php endif; ?><?php /**PATH D:\Web Development\simpeg\resources\views/dashboards/staff_marketing.blade.php ENDPATH**/ ?>