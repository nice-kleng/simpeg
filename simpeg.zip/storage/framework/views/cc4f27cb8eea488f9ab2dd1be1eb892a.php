

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Form Mitra</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form action="<?php echo e(route('mitra.store')); ?>" method="POST" class="row">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-md-6">
                            <label for="kode">Kode Mitra</label>
                            <input type="text" class="form-control" id="kode" name="kode" value="<?php echo e(old('kode')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="tanggal">Tanggal Gabung</label>
                            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?php echo e(old('tanggal')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="nama">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="status_mitra">Status Mitra</label>
                            <select name="status_mitra" id="status_mitra" class="form-control">
                                <option value="Reseller" <?php echo e(old('status_mitra') == 'Reseller' ? 'selected' : ''); ?>>Reseller</option>
                                <option value="Agen" <?php echo e(old('status_mitra') == 'Agen' ? 'selected' : ''); ?>>Agen</option>
                                <option value="Sub Distributor" <?php echo e(old('status_mitra') == 'Sub Distributor' ? 'selected' : ''); ?>>Sub Distributor</option>
                                <option value="Distributor" <?php echo e(old('status_mitra') == 'Distributor' ? 'selected' : ''); ?>>Distributor</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="kota_wilayah">Kota/Wilayah</label>
                            <input type="text" class="form-control" id="kota_wilayah" name="kota_wilayah" value="<?php echo e(old('kota_wilayah')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="fb">Facebook</label>
                            <input type="text" class="form-control" id="fb" name="fb" value="<?php echo e(old('fb')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="ig">Instagram</label>
                            <input type="text" class="form-control" id="ig" name="ig" value="<?php echo e(old('ig')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="marketplace">Marketplace</label>
                            <input type="text" class="form-control" id="marketplace" name="marketplace" value="<?php echo e(old('marketplace')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="no_hp">No Hp</label>
                            <input type="text" class="form-control" id="no_hp" name="no_hp" value="<?php echo e(old('no_hp')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="upline">Upline</label>
                            <select name="upline" id="upline" class="form-control">
                                <option value="">Pilih Upline</option>
                                <?php $__currentLoopData = $uplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($upline->id); ?>" <?php echo e(old('upline') == $upline->id ? 'selected' : ''); ?>><?php echo e($upline->nama . '|' . $upline->status_mitra); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="bulan">Bulan</label>
                            <select name="bulan" id="bulan" class="form-control">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e(Carbon\Carbon::create()->month($i)->locale('id')->monthName); ?>" <?php echo e(old('bulan') == Carbon\Carbon::create()->month($i)->locale('id')->monthName ? 'selected' : ''); ?>><?php echo e(Carbon\Carbon::create()->month($i)->locale('id')->monthName); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="note_1">Note 1</label>
                            <select name="note_1" id="note_1" class="form-control">
                                <option value="New Mitra">New Mitra</option>
                                <option value="Upgrade">Upgrade</option>
                                <option value="Downgrade">Downgrade</option>
                                <option value="Move">Move</option>
                                <option value="Blacklist">Blacklist</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="note_2">Note 2</label>
                            <input type="text" class="form-control" id="note_2" name="note_2" value="<?php echo e(old('note_2')); ?>" required>
                        </div>
                        <div class="form-group col-md-6" style="margin-top: 25px;">   
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <a href="<?php echo e(route('mitra.index')); ?>" class="btn btn-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageTitle' => 'Tambah Data Mitra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\simpeg\resources\views/superadmin/mitra/create.blade.php ENDPATH**/ ?>