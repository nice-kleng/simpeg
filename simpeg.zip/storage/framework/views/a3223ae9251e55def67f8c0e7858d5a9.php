<!-- jQuery -->
<script src="<?php echo e(asset('assets/vendors/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('assets/vendors/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('assets/vendors/fastclick/lib/fastclick.js')); ?>"></script>
<!-- NProgress -->
<script src="<?php echo e(asset('assets/vendors/nprogress/nprogress.js')); ?>"></script>

<!-- Custom Theme Scripts -->
<script src="<?php echo e(asset('assets/build/js/custom.min.js')); ?>"></script>

<!-- DataTables -->
<script src="<?php echo e(asset('assets/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?>"></script>

<!-- PNotify -->
<script src="<?php echo e(asset('assets/vendors/pnotify/dist/pnotify.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/pnotify/dist/pnotify.buttons.js')); ?>"></script>


<?php if(session('message')): ?>
    <script>
        new PNotify({
            title: '<?php echo e(session('title')); ?>',
            text: '<?php echo e(session('message')); ?>',
            type: '<?php echo e(session('type')); ?>',
            styling: 'bootstrap3',
        });
    </script>
<?php endif; ?>

<script>
    function deleteData(el) {
        let url = $(el).attr('data-url');
        $('#confirm-delete').modal('show');
        $('#form-delete').attr('action', url);
    }
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH D:\Web Development\simpeg\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>