<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Data Turlap</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-nowrap" id="turlap-table" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Area</th>
                                <th>Nama</th>
                                <th>Rating</th>
                                <th>Alamat</th>
                                <th>No HP</th>
                                <th>Brand</th>
                                <th>Pic</th>
                                <th>Pic Sign</th>
                                <th>Maps</th>
                                <th>Tanggal</th>
                                <th>Status Follow Up</th>
                            </tr>
                            <tbody>
                        </thead>
                            <?php $__currentLoopData = $marketings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($marketing->sumberMarketing->nama_sumber_marketing); ?></td>
                                <td><?php echo e($marketing->nama); ?></td>
                                <td><?php echo e($marketing->rating); ?></td>
                                <td><?php echo e($marketing->alamat); ?></td>
                                <td><?php echo e($marketing->no_hp); ?></td>
                                <td><?php echo e($marketing->brand); ?></td>
                                <td><?php echo e($marketing->pics->pluck('name')->implode(', ')); ?></td>
                                <td><?php echo e($marketing->picSign->pluck('name')->implode(', ')); ?></td>
                                <td><?php echo e($marketing->maps); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($marketing->tanggal)->locale('id')->isoFormat('D MMMM YYYY')); ?></td>
                                <td>
                                    <?php
                                        $lastFollowUp = $marketing->followUp->last();
                                        $status = $lastFollowUp ? $lastFollowUp->getRawOriginal('status') : null;
                                        $badgeColor = '';
                                        $badgeText = 'Not Started';

                                        if ($status === '1') {
                                            $badgeColor = 'primary';
                                            $badgeText = 'Follow Up';
                                        } elseif ($status === '2') {
                                            $badgeColor = 'danger';
                                            $badgeText = 'Ditolak';
                                        } elseif ($status === '3') {
                                            $badgeColor = 'success';
                                            $badgeText = 'Join';
                                        } else {
                                            $badgeColor = 'secondary';
                                        }
                                    ?>
                                    <span class="badge badge-<?php echo e($badgeColor); ?>">
                                        <?php echo e($badgeText); ?>

                                    </span>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#turlap-table').DataTable();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageTitle' => 'Data Turlap'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\simpeg\resources\views/marketing/turlap/viewTurlap.blade.php ENDPATH**/ ?>