<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View Marketing Kadiv Dashboard')): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4>Dashboard Kadiv Marketing</h4>
                </div>
                <div class="x_content">
                    <div class="row">
                    </div>
                </div>
            </div> 
        </div>
    </div>
<?php endif; ?><?php /**PATH D:\Web Development\simpeg\resources\views/dashboards/kadiv_marketing.blade.php ENDPATH**/ ?>