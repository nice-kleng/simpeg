<!-- Bootstrap -->
<link href="<?php echo e(asset('/assets/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(asset('/assets/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<!-- NProgress -->
<link href="<?php echo e(asset('/assets/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="<?php echo e(asset('/assets/build/css/custom.min.css')); ?>" rel="stylesheet">

<!-- DataTables -->
<link href="<?php echo e(asset('/assets/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">

<!-- PNotify -->
<link href="<?php echo e(asset('/assets/vendors/pnotify/dist/pnotify.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/vendors/pnotify/dist/pnotify.buttons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/vendors/pnotify/dist/pnotify.nonblock.css')); ?>" rel="stylesheet">
<?php echo $__env->yieldPushContent('styles'); ?>
<?php /**PATH D:\Web Development\simpeg\resources\views/layouts/style.blade.php ENDPATH**/ ?>