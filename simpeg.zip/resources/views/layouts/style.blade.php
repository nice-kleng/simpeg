<!-- Bootstrap -->
<link href="{{ asset('/assets/vendors/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{ asset('/assets/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
<!-- NProgress -->
<link href="{{ asset('/assets/vendors/nprogress/nprogress.css') }}" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="{{ asset('/assets/build/css/custom.min.css') }}" rel="stylesheet">

<!-- DataTables -->
<link href="{{ asset('/assets/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css') }}" rel="stylesheet">

<!-- PNotify -->
<link href="{{ asset('/assets/vendors/pnotify/dist/pnotify.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/vendors/pnotify/dist/pnotify.buttons.css') }}" rel="stylesheet">
<link href="{{ asset('/assets/vendors/pnotify/dist/pnotify.nonblock.css') }}" rel="stylesheet">
@stack('styles')
