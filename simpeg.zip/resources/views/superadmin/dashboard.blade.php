@extends('layouts.app', ['pageTitle' => 'Dashboard'])

@section('content')
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Dashboard</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <p>Welcome to the dashboard</p>
            </div>
        </div>
    </div>
</div>
@endsection
